import{h as Y}from"./chunk-OQ3CQOFM.js";import{Ma as X,ea as H,fa as U,ga as J,ka as W}from"./chunk-JLH6U4MG.js";import{i as L,l as q,n as $,s as G}from"./chunk-IG6V3IUZ.js";import{$ as E,$a as D,Ab as f,Eb as u,Ga as P,Gb as r,Hb as j,Ib as z,Ic as K,Jb as I,Ka as s,Lb as w,Mb as T,P as k,Pb as A,Qb as O,Tb as m,U as V,Ub as R,Vb as B,Xa as S,Z as p,_ as l,bb as _,db as b,dc as N,ka as M,la as x,lb as d,qb as c,rb as g,sb as h,sc as Q,tb as F,xb as y,yb as C}from"./chunk-CM7YQ5L2.js";var Z=`
    .p-chip {
        display: inline-flex;
        align-items: center;
        background: dt('chip.background');
        color: dt('chip.color');
        border-radius: dt('chip.border.radius');
        padding-block: dt('chip.padding.y');
        padding-inline: dt('chip.padding.x');
        gap: dt('chip.gap');
    }

    .p-chip-icon {
        color: dt('chip.icon.color');
        font-size: dt('chip.icon.font.size');
        width: dt('chip.icon.size');
        height: dt('chip.icon.size');
    }

    .p-chip-image {
        border-radius: 50%;
        width: dt('chip.image.width');
        height: dt('chip.image.height');
        margin-inline-start: calc(-1 * dt('chip.padding.y'));
    }

    .p-chip:has(.p-chip-remove-icon) {
        padding-inline-end: dt('chip.padding.y');
    }

    .p-chip:has(.p-chip-image) {
        padding-block-start: calc(dt('chip.padding.y') / 2);
        padding-block-end: calc(dt('chip.padding.y') / 2);
    }

    .p-chip-remove-icon {
        cursor: pointer;
        font-size: dt('chip.remove.icon.size');
        width: dt('chip.remove.icon.size');
        height: dt('chip.remove.icon.size');
        color: dt('chip.remove.icon.color');
        border-radius: 50%;
        transition:
            outline-color dt('chip.transition.duration'),
            box-shadow dt('chip.transition.duration');
        outline-color: transparent;
    }

    .p-chip-remove-icon:focus-visible {
        box-shadow: dt('chip.remove.icon.focus.ring.shadow');
        outline: dt('chip.remove.icon.focus.ring.width') dt('chip.remove.icon.focus.ring.style') dt('chip.remove.icon.focus.ring.color');
        outline-offset: dt('chip.remove.icon.focus.ring.offset');
    }
`;var ne=["removeicon"],te=["*"];function ie(n,a){if(n&1){let e=f();g(0,"img",4),u("error",function(i){p(e);let o=r();return l(o.imageError(i))}),h()}if(n&2){let e=r();m(e.cx("image")),c("src",e.image,P)("alt",e.alt)}}function oe(n,a){if(n&1&&F(0,"span",6),n&2){let e=r(2);m(e.icon),c("ngClass",e.cx("icon")),d("data-pc-section","icon")}}function re(n,a){if(n&1&&_(0,oe,1,4,"span",5),n&2){let e=r();c("ngIf",e.icon)}}function ce(n,a){if(n&1&&(g(0,"div"),R(1),h()),n&2){let e=r();m(e.cx("label")),d("data-pc-section","label"),s(),B(e.label)}}function ae(n,a){if(n&1){let e=f();g(0,"span",10),u("click",function(i){p(e);let o=r(3);return l(o.close(i))})("keydown",function(i){p(e);let o=r(3);return l(o.onKeydown(i))}),h()}if(n&2){let e=r(3);m(e.removeIcon),c("ngClass",e.cx("removeIcon")),d("data-pc-section","removeicon")("aria-label",e.removeAriaLabel)}}function se(n,a){if(n&1){let e=f();E(),g(0,"svg",11),u("click",function(i){p(e);let o=r(3);return l(o.close(i))})("keydown",function(i){p(e);let o=r(3);return l(o.onKeydown(i))}),h()}if(n&2){let e=r(3);m(e.cx("removeIcon")),d("data-pc-section","removeicon")("aria-label",e.removeAriaLabel)}}function pe(n,a){if(n&1&&(y(0),_(1,ae,1,5,"span",8)(2,se,1,4,"svg",9),C()),n&2){let e=r(2);s(),c("ngIf",e.removeIcon),s(),c("ngIf",!e.removeIcon)}}function le(n,a){}function me(n,a){n&1&&_(0,le,0,0,"ng-template")}function _e(n,a){if(n&1){let e=f();g(0,"span",12),u("click",function(i){p(e);let o=r(2);return l(o.close(i))})("keydown",function(i){p(e);let o=r(2);return l(o.onKeydown(i))}),_(1,me,1,0,null,13),h()}if(n&2){let e=r(2);m(e.cx("removeIcon")),d("data-pc-section","removeicon")("aria-label",e.removeAriaLabel),s(),c("ngTemplateOutlet",e.removeIconTemplate||e._removeIconTemplate)}}function de(n,a){if(n&1&&(y(0),_(1,pe,3,2,"ng-container",3)(2,_e,2,5,"span",7),C()),n&2){let e=r();s(),c("ngIf",!e.removeIconTemplate&&!e._removeIconTemplate),s(),c("ngIf",e.removeIconTemplate||e._removeIconTemplate)}}var ge={root:()=>["p-chip p-component"],image:"p-chip-image",icon:"p-chip-icon",label:"p-chip-label",removeIcon:"p-chip-remove-icon"},ee=(()=>{class n extends W{name="chip";theme=Z;classes=ge;static \u0275fac=(()=>{let e;return function(i){return(e||(e=x(n)))(i||n)}})();static \u0275prov=k({token:n,factory:n.\u0275fac})}return n})();var Ae=(()=>{class n extends X{label;icon;image;alt;styleClass;removable=!1;removeIcon;onRemove=new b;onImageError=new b;visible=!0;get removeAriaLabel(){return this.config.getTranslation(J.ARIA).removeLabel}get chipProps(){return this._chipProps}set chipProps(e){this._chipProps=e,e&&typeof e=="object"&&Object.entries(e).forEach(([t,i])=>this[`_${t}`]!==i&&(this[`_${t}`]=i))}_chipProps;_componentStyle=V(ee);removeIconTemplate;templates;_removeIconTemplate;ngAfterContentInit(){this.templates.forEach(e=>{switch(e.getType()){case"removeicon":this._removeIconTemplate=e.template;break;default:this._removeIconTemplate=e.template;break}})}ngOnChanges(e){if(super.ngOnChanges(e),e.chipProps&&e.chipProps.currentValue){let{currentValue:t}=e.chipProps;t.label!==void 0&&(this.label=t.label),t.icon!==void 0&&(this.icon=t.icon),t.image!==void 0&&(this.image=t.image),t.alt!==void 0&&(this.alt=t.alt),t.styleClass!==void 0&&(this.styleClass=t.styleClass),t.removable!==void 0&&(this.removable=t.removable),t.removeIcon!==void 0&&(this.removeIcon=t.removeIcon)}}close(e){this.visible=!1,this.onRemove.emit(e)}onKeydown(e){(e.key==="Enter"||e.key==="Backspace")&&this.close(e)}imageError(e){this.onImageError.emit(e)}static \u0275fac=(()=>{let e;return function(i){return(e||(e=x(n)))(i||n)}})();static \u0275cmp=S({type:n,selectors:[["p-chip"]],contentQueries:function(t,i,o){if(t&1&&(I(o,ne,4),I(o,H,4)),t&2){let v;w(v=T())&&(i.removeIconTemplate=v.first),w(v=T())&&(i.templates=v)}},hostVars:7,hostBindings:function(t,i){t&2&&(d("data-pc-name","chip")("aria-label",i.label)("data-pc-section","root"),m(i.cn(i.cx("root"),i.styleClass)),O("display",!i.visible&&"none"))},inputs:{label:"label",icon:"icon",image:"image",alt:"alt",styleClass:"styleClass",removable:[2,"removable","removable",K],removeIcon:"removeIcon",chipProps:"chipProps"},outputs:{onRemove:"onRemove",onImageError:"onImageError"},features:[N([ee]),D,M],ngContentSelectors:te,decls:6,vars:4,consts:[["iconTemplate",""],[3,"class","src","alt","error",4,"ngIf","ngIfElse"],[3,"class",4,"ngIf"],[4,"ngIf"],[3,"error","src","alt"],[3,"class","ngClass",4,"ngIf"],[3,"ngClass"],["tabindex","0","role","button",3,"class","click","keydown",4,"ngIf"],["tabindex","0","role","button",3,"class","ngClass","click","keydown",4,"ngIf"],["data-p-icon","times-circle","tabindex","0","role","button",3,"class","click","keydown",4,"ngIf"],["tabindex","0","role","button",3,"click","keydown","ngClass"],["data-p-icon","times-circle","tabindex","0","role","button",3,"click","keydown"],["tabindex","0","role","button",3,"click","keydown"],[4,"ngTemplateOutlet"]],template:function(t,i){if(t&1&&(j(),z(0),_(1,ie,1,4,"img",1)(2,re,1,1,"ng-template",null,0,Q)(4,ce,2,4,"div",2)(5,de,3,2,"ng-container",3)),t&2){let o=A(3);s(),c("ngIf",i.image)("ngIfElse",o),s(3),c("ngIf",i.label),s(),c("ngIf",i.removable)}},dependencies:[G,L,q,$,Y,U],encapsulation:2,changeDetection:0})}return n})();export{Ae as a};
