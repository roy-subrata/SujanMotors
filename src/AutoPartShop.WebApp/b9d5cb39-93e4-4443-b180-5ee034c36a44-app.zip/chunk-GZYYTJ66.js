var e={production:!1,apiUrl:"https://smautoapi-dxecdjehhuf8awh9.eastasia-01.azurewebsites.net/api"};export{e as a};
