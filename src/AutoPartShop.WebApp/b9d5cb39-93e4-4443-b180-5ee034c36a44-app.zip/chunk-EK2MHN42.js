import{Ma as X,fa as m,ka as J}from"./chunk-JLH6U4MG.js";import{a as h}from"./chunk-GZYYTJ66.js";import{A as c,i as Q,l as W,s as G,z as T}from"./chunk-IG6V3IUZ.js";import{$a as A,Ab as S,Eb as B,Ga as j,Gb as o,Hb as F,Ib as M,Ka as b,L,P as s,Pb as x,Q as O,T as U,Tb as u,U as l,Ub as D,Vb as q,Xa as E,Ya as k,Z as z,_ as w,bb as g,c as I,db as N,dc as H,g as _,ga as d,la as v,lb as f,qb as p,rb as C,sb as y,sc as R,tb as P,xc as V}from"./chunk-CM7YQ5L2.js";var Y=`
    .p-avatar {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: dt('avatar.width');
        height: dt('avatar.height');
        font-size: dt('avatar.font.size');
        background: dt('avatar.background');
        color: dt('avatar.color');
        border-radius: dt('avatar.border.radius');
    }

    .p-avatar-image {
        background: transparent;
    }

    .p-avatar-circle {
        border-radius: 50%;
    }

    .p-avatar-circle img {
        border-radius: 50%;
    }

    .p-avatar-icon {
        font-size: dt('avatar.icon.size');
        width: dt('avatar.icon.size');
        height: dt('avatar.icon.size');
    }

    .p-avatar img {
        width: 100%;
        height: 100%;
    }

    .p-avatar-lg {
        width: dt('avatar.lg.width');
        height: dt('avatar.lg.width');
        font-size: dt('avatar.lg.font.size');
    }

    .p-avatar-lg .p-avatar-icon {
        font-size: dt('avatar.lg.icon.size');
        width: dt('avatar.lg.icon.size');
        height: dt('avatar.lg.icon.size');
    }

    .p-avatar-xl {
        width: dt('avatar.xl.width');
        height: dt('avatar.xl.width');
        font-size: dt('avatar.xl.font.size');
    }

    .p-avatar-xl .p-avatar-icon {
        font-size: dt('avatar.xl.icon.size');
        width: dt('avatar.xl.icon.size');
        height: dt('avatar.xl.icon.size');
    }

    .p-avatar-group {
        display: flex;
        align-items: center;
    }

    .p-avatar-group .p-avatar + .p-avatar {
        margin-inline-start: dt('avatar.group.offset');
    }

    .p-avatar-group .p-avatar {
        border: 2px solid dt('avatar.group.border.color');
    }

    .p-avatar-group .p-avatar-lg + .p-avatar-lg {
        margin-inline-start: dt('avatar.lg.group.offset');
    }

    .p-avatar-group .p-avatar-xl + .p-avatar-xl {
        margin-inline-start: dt('avatar.xl.group.offset');
    }
`;var at=["*"];function nt(a,t){if(a&1&&(C(0,"span"),D(1),y()),a&2){let e=o();u(e.cx("label")),b(),q(e.label)}}function rt(a,t){if(a&1&&P(0,"span",4),a&2){let e=o(2);u(e.icon),p("ngClass",e.cx("icon"))}}function it(a,t){if(a&1&&g(0,rt,1,3,"span",3),a&2){let e=o(),r=x(5);p("ngIf",e.icon)("ngIfElse",r)}}function st(a,t){if(a&1){let e=S();C(0,"img",6),B("error",function(n){z(e);let i=o(2);return w(i.imageError(n))}),y()}if(a&2){let e=o(2);p("src",e.image,j),f("aria-label",e.ariaLabel)}}function ot(a,t){if(a&1&&g(0,st,1,2,"img",5),a&2){let e=o();p("ngIf",e.image)}}var lt={root:({instance:a})=>["p-avatar p-component",{"p-avatar-image":a.image!=null,"p-avatar-circle":a.shape==="circle","p-avatar-lg":a.size==="large","p-avatar-xl":a.size==="xlarge"}],label:"p-avatar-label",icon:"p-avatar-icon"},Z=(()=>{class a extends J{name="avatar";theme=Y;classes=lt;static \u0275fac=(()=>{let e;return function(n){return(e||(e=v(a)))(n||a)}})();static \u0275prov=s({token:a,factory:a.\u0275fac})}return a})();var pt=(()=>{class a extends X{label;icon;image;size="normal";shape="square";styleClass;ariaLabel;ariaLabelledBy;onImageError=new N;_componentStyle=l(Z);imageError(e){this.onImageError.emit(e)}static \u0275fac=(()=>{let e;return function(n){return(e||(e=v(a)))(n||a)}})();static \u0275cmp=E({type:a,selectors:[["p-avatar"]],hostVars:5,hostBindings:function(r,n){r&2&&(f("data-pc-name","avatar")("aria-label",n.ariaLabel)("aria-labelledby",n.ariaLabelledBy),u(n.cn(n.cx("root"),n.styleClass)))},inputs:{label:"label",icon:"icon",image:"image",size:"size",shape:"shape",styleClass:"styleClass",ariaLabel:"ariaLabel",ariaLabelledBy:"ariaLabelledBy"},outputs:{onImageError:"onImageError"},features:[H([Z]),A],ngContentSelectors:at,decls:6,vars:2,consts:[["iconTemplate",""],["imageTemplate",""],[3,"class",4,"ngIf","ngIfElse"],[3,"class","ngClass",4,"ngIf","ngIfElse"],[3,"ngClass"],[3,"src","error",4,"ngIf"],[3,"error","src"]],template:function(r,n){if(r&1&&(F(),M(0),g(1,nt,2,3,"span",2)(2,it,1,2,"ng-template",null,0,R)(4,ot,1,1,"ng-template",null,1,R)),r&2){let i=x(3);b(),p("ngIf",n.label)("ngIfElse",i)}},dependencies:[G,Q,W,m],encapsulation:2,changeDetection:0})}return a})(),It=(()=>{class a{static \u0275fac=function(r){return new(r||a)};static \u0275mod=k({type:a});static \u0275inj=O({imports:[pt,m,m]})}return a})();var K=class a{constructor(t){this.httpClient=t}currentLang=d("en");translations=d({});fallbackTranslations={};translationsLoaded=new _(!1);initialize(){return new I(t=>{this.httpClient.get("/assets/i18n/en.json").subscribe({next:e=>{this.fallbackTranslations=e,this.translations.set(e);let r=localStorage.getItem("appLanguage");r&&r!=="en"?(this.currentLang.set(r),this.loadLanguage(r).subscribe({next:()=>{this.translationsLoaded.next(!0),t.next(this.translations()),t.complete()},error:n=>{console.warn(`Failed to load saved language '${r}', using English`,n),this.currentLang.set("en"),this.translationsLoaded.next(!0),t.next(this.translations()),t.complete()}})):(this.currentLang.set("en"),this.translationsLoaded.next(!0),t.next(e),t.complete())},error:e=>{console.error("Failed to load English fallback translations",e),t.error(e)}})})}loadLanguage(t){return this.httpClient.get(`/assets/i18n/${t}.json`).pipe(L(e=>{this.translations.set(e),this.currentLang.set(t),localStorage.setItem("appLanguage",t),this.translationsLoaded.next(!0)}))}setLanguage(t){this.currentLang.set(t),localStorage.setItem("appLanguage",t),this.loadLanguage(t).subscribe({error:e=>{console.error(`Failed to load language: ${t}`,e),t!=="en"&&this.translations.set(this.fallbackTranslations)}})}getCurrentLanguage(){return this.currentLang()}translate(t,e){let r=t.split("."),n=this.translations();for(let i of r)if(n&&typeof n=="object"&&i in n)n=n[i];else{n=this.getFallbackTranslation(t);break}return typeof n!="string"?t:(e&&Object.keys(e).forEach(i=>{n=n.replace(`{{${i}}}`,e[i])}),n)}getFallbackTranslation(t){let e=t.split("."),r=this.fallbackTranslations;for(let n of e)if(r&&typeof r=="object"&&n in r)r=r[n];else return t;return typeof r=="string"?r:t}t(t,e){return this.translate(t,e)}get translationsLoaded$(){return this.translationsLoaded.asObservable()}get currentLanguage$(){return V(()=>this.currentLang())}static \u0275fac=function(e){return new(e||a)(U(c))};static \u0275prov=s({token:a,factory:a.\u0275fac,providedIn:"root"})};var tt=class a{http=l(c);apiUrl=`${h.apiUrl}/customer`;getAllCustomers(){return this.http.get(this.apiUrl)}getCustomers(t){return this.http.post(`${this.apiUrl}/list`,t)}getCustomerById(t){return this.http.get(`${this.apiUrl}/${t}`)}getCustomerByCode(t){return this.http.get(`${this.apiUrl}/code/${t}`)}getCustomerByEmail(t){return this.http.get(`${this.apiUrl}/email/${t}`)}getCustomersByStatus(t){return this.http.get(`${this.apiUrl}/status/${t}`)}getActiveCustomers(){return this.http.get(`${this.apiUrl}/active`)}getCustomersWithCreditExceeded(){return this.http.get(`${this.apiUrl}/credit-exceeded`)}createCustomer(t){return this.http.post(this.apiUrl,t)}updateCustomer(t,e){return this.http.put(`${this.apiUrl}/${t}`,e)}activateCustomer(t){return this.http.patch(`${this.apiUrl}/${t}/activate`,{})}deactivateCustomer(t){return this.http.patch(`${this.apiUrl}/${t}/deactivate`,{})}suspendCustomer(t){return this.http.patch(`${this.apiUrl}/${t}/suspend`,{})}blacklistCustomer(t){return this.http.patch(`${this.apiUrl}/${t}/blacklist`,{})}deleteCustomer(t){return this.http.delete(`${this.apiUrl}/${t}`)}static \u0275fac=function(e){return new(e||a)};static \u0275prov=s({token:a,factory:a.\u0275fac,providedIn:"root"})};var et=class a{http=l(c);apiUrl=`${h.apiUrl}/technician`;getAllTechnicians(){return this.http.get(this.apiUrl)}getTechnicians(t=1,e=10,r){let n=new T().set("pageNumber",t.toString()).set("pageSize",e.toString());return r&&(n=n.set("searchTerm",r)),this.http.get(`${this.apiUrl}/list`,{params:n})}getTechnicianById(t){return this.http.get(`${this.apiUrl}/${t}`)}createTechnician(t){return this.http.post(this.apiUrl,t)}updateTechnician(t,e){return this.http.put(`${this.apiUrl}/${t}`,e)}activateTechnician(t){return this.http.patch(`${this.apiUrl}/${t}/activate`,{})}deactivateTechnician(t){return this.http.patch(`${this.apiUrl}/${t}/deactivate`,{})}deleteTechnician(t){return this.http.delete(`${this.apiUrl}/${t}`)}searchTechnicians(t){return this.http.get(`${this.apiUrl}/search`,{params:new T().set("query",t)})}getActiveTechnicians(){return this.http.get(`${this.apiUrl}/active`)}static \u0275fac=function(e){return new(e||a)};static \u0275prov=s({token:a,factory:a.\u0275fac,providedIn:"root"})};export{pt as a,It as b,K as c,tt as d,et as e};
